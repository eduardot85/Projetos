<?php
/*
Plugin Name: pluginWP
Plugin URI: http://pluginWP.com
Description: Plugin is counting bots visits
Author: Greg
Version: 1.0
Author URI: http://ditio.net
*/


add_action( 'init', 'create_post_type' );
function create_post_type() {
		
  register_post_type( 'cliente',
	    array(
	      'labels' => array(
	        'name' => __( 'Cliente' ),
	        'singular_name' => __( 'Cliente' )
	      ),
	      'public' => true,
	      'has_archive' => true,
		  'fields' => array(
	          array(
	              'name' => 'Featured Theme',
	              'desc' => 'Select the featured theme',
	              'id' => 'featured_theme',
	              'type' => 'imag_select_taxonomy',
	              'taxonomy' => 'imag_theme',
	          ),
	      ),
 	      'supports' => array( 
			  'smashing-post-class' 
			)
	    )
  );

  register_post_type( 'produto',
    array(
      'labels' => array(
        'name' => __( 'Produto' ),
        'singular_name' => __( 'Produto Singular' )
      ),
      'public' => true,
      'has_archive' => true,
      'supports' => array( 
		  'smashing-post-class' 
		)
    )
  );

  register_post_type( 'pedido',
    array(
      'labels' => array(
        'name' => __( 'Pedido' ),
        'singular_name' => __( 'Pedido Singular' ),
		'from'  => 'produto',
      ),
      'public' => true,
      'has_archive' => true,
    )
  );

}

include('metaboxes.php'); 
 
?>

