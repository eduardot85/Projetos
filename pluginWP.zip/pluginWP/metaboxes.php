<?php

add_action( 'load-post.php', 'setup_metaboxes' );
add_action( 'load-post-new.php', 'setup_metaboxes' );


function setup_metaboxes() {

  /* Add meta boxes on the 'add_meta_boxes' hook. */
  add_action( 'add_meta_boxes', 'adiciona_todas_metabox' );
  add_action( 'save_post', 'salva_metaboxes', 10, 2 );
  echo 'dalva';
  
}

function adiciona_todas_metabox() {

   add_meta_box(
      'nome_cliente',      // Unique ID
      esc_html__( 'Nome Cliente', 'example' ),    // Title
      'metabox_nomecliente',   // Callback function
      'cliente',         // Admin page (or post type)
      'normal',         // Context
      'default'         // Priority
    );

  add_meta_box(
    'email_cliente',      // Unique ID
    esc_html__( 'Email Cliente', 'example' ),    // Title
    'metabox_email',   // Callback function
    'cliente',         // Admin page (or post type)
    'normal',         // Context
    'default'         // Priority
  );
  

  add_meta_box(
    'telefone_cliente',      // Unique ID
    esc_html__( 'Telefone Cliente', 'example' ),    // Title
    'metabox_telefone',   // Callback function
    'cliente',         // Admin page (or post type)
    'normal',         // Context
    'default'         // Priority
  );  
  

  add_meta_box(
     'nome_produto',      // Unique ID
     esc_html__( 'Nome Produto', 'example' ),    // Title
     'metabox_nomeproduto',   // Callback function
     'produto',         // Admin page (or post type)
     'normal',         // Context
     'default'         // Priority
   );
  
  
}

function metabox_nomecliente( $object, $box ) { ?>

  <?php wp_nonce_field( basename( __FILE__ ), 'nome_cliente' ); ?>

  <p>
    <label for="email_cliente"><?php _e( "Nome", 'example' ); ?></label>
    <br />
    <input class="widefat" type="text" name="nome_cliente" id="nome_cliente" value="<?php echo esc_attr( get_post_meta( $object->ID, 'nome_cliente', true ) ); ?>" size="30" />
  </p>
<?php
 }
 

 function metabox_nomeproduto( $object, $box ) { ?>

   <?php wp_nonce_field( basename( __FILE__ ), 'nome_produto' ); ?>

   <p>
     <label for="nome_produto"><?php _e( "Nome", 'example' ); ?></label>
     <br />
     <input class="widefat" type="text" name="nome_cliente" id="nome_produto" value="<?php echo esc_attr( get_post_meta( $object->ID, 'nome_produto', true ) ); ?>" size="30" />
   </p>
 <?php
  }
 
 
function metabox_email( $object, $box ) { ?>

  <?php wp_nonce_field( basename( __FILE__ ), 'email_cliente' ); ?>

  <p>
    <label for="email_cliente"><?php _e( "E-mail do cliente.", 'example' ); ?></label>
    <br />
    <input class="widefat" type="text" name="email_cliente" id="email_cliente" value="<?php echo esc_attr( get_post_meta( $object->ID, 'email_cliente', true ) ); ?>" size="30" />
  </p>
<?php
 }
 

 function metabox_telefone( $object, $box ) { ?>

   <?php wp_nonce_field( basename( __FILE__ ), 'telefone_cliente' ); ?>

   <p>
     <label for="telefone_cliente"><?php _e( "Telefone", 'example' ); ?></label>
     <br />
     <input class="widefat" type="text" name="telefone_cliente" id="telefone_cliente" value="<?php echo esc_attr( get_post_meta( $object->ID, 'telefone_cliente', true ) ); ?>" size="30" />
   </p>
 <?php
  } 
 
 
?>



?>